# Stanford controlled release project 2021

Code and Data from testing in Midland TX and Ehrenberg AZ. 
